package com.ecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.ConditionalOnEnabledResourceChain;


@SpringBootApplication
public class KoushikaAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(KoushikaAccountApplication.class, args);
	}

}
