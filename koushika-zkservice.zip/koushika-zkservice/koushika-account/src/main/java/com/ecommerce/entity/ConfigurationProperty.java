package com.ecommerce.entity;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

@Service
@ConfigurationProperties(prefix = "koushika")
public class ConfigurationProperty {

	private String minimumValue;

	private String maximumValue;

	public String getMinimumValue() {
		return minimumValue;
	}

	public void setMinimumValue(String minimumValue) {
		this.minimumValue = minimumValue;
	}

	public String getMaximumValue() {
		return maximumValue;
	}

	public void setMaximumValue(String maximumValue) {
		this.maximumValue = maximumValue;
	}

	public ConfigurationProperty() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ConfigurationProperty(String minimumValue, String maximumValue) {
		super();
		this.minimumValue = minimumValue;
		this.maximumValue = maximumValue;
	}

}
