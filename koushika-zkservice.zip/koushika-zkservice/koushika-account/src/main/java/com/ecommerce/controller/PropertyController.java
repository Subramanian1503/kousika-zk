package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.entity.ConfigurationProperty;

@RestController
public class PropertyController {

	@Autowired
	private ConfigurationProperty configurationProperty;

	@GetMapping("/getProperties")
	public ConfigurationProperty getProperties() {
		return configurationProperty;
	}

}
